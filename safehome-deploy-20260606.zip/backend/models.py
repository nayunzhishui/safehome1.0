"""SQLite schema for the SafeHome MVP backend."""

MVP_TABLES = [
    "users",
    "schema_migrations",
    "goals",
    "emotion_diaries",
    "feedback_results",
    "training_cards",
    "checkins",
    "assessment_results",
    "student_profiles",
    "profile_reviews",
    "student_profile_followups",
    "student_sandplay_entries",
    "parent_assessment_submissions",
    "parent_report_actions",
    "records",
    "audit_logs",
    "privacy_requests",
    "family_links",
    "weekly_reports",
    "supervision_requests",
]


SCHEMA_SQL = [
    """
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        nickname TEXT,
        role TEXT DEFAULT 'parent',
        source TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS privacy_requests (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        request_type TEXT NOT NULL,
        reason TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        handled_by TEXT,
        handled_note TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS family_links (
        id TEXT PRIMARY KEY,
        parent_user_id TEXT NOT NULL,
        student_user_id TEXT,
        bind_code TEXT NOT NULL,
        relation_label TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        expires_at TEXT,
        attempt_count INTEGER NOT NULL DEFAULT 0,
        last_attempt_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        confirmed_at TEXT,
        revoked_at TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS schema_migrations (
        version TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        applied_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS goals (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        scene TEXT NOT NULL,
        smart_goal TEXT NOT NULL,
        motivation TEXT,
        start_date TEXT,
        status TEXT NOT NULL DEFAULT 'active',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS emotion_diaries (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        goal_id TEXT,
        event_time TEXT,
        scene TEXT NOT NULL,
        event_description TEXT NOT NULL,
        parent_emotion TEXT NOT NULL,
        parent_emotion_intensity INTEGER NOT NULL,
        child_emotion TEXT,
        child_emotion_intensity INTEGER,
        automatic_thought TEXT,
        body_sensation TEXT,
        behavior TEXT,
        raw_text TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS feedback_results (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        diary_id TEXT,
        tags_json TEXT NOT NULL,
        trigger_summary TEXT,
        pattern_summary TEXT,
        supportive_feedback TEXT NOT NULL,
        alternative_response TEXT,
        recommended_card_ids_json TEXT NOT NULL,
        risk_level TEXT NOT NULL DEFAULT 'low',
        created_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS training_cards (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        title TEXT NOT NULL,
        purpose TEXT,
        steps_json TEXT NOT NULL,
        tags_json TEXT NOT NULL,
        example TEXT,
        duration_minutes INTEGER,
        enabled INTEGER NOT NULL DEFAULT 1,
        version TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS checkins (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        card_id TEXT NOT NULL,
        diary_id TEXT,
        completed INTEGER NOT NULL,
        emotion_before INTEGER,
        emotion_after INTEGER,
        reflection TEXT,
        created_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS assessment_results (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        worksheet_id TEXT NOT NULL,
        worksheet_title TEXT NOT NULL,
        category TEXT,
        answers_json TEXT NOT NULL,
        scores_json TEXT NOT NULL,
        total_score INTEGER,
        result_summary TEXT,
        created_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS student_profiles (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        anonymous_id TEXT NOT NULL,
        assessment_result_id TEXT,
        round INTEGER NOT NULL DEFAULT 1,
        source TEXT,
        scores_json TEXT NOT NULL,
        text_features_json TEXT NOT NULL,
        profile_code TEXT NOT NULL,
        profile_name TEXT NOT NULL,
        confidence REAL,
        dimensions_json TEXT NOT NULL,
        recommended_task_ids_json TEXT NOT NULL,
        risk_level TEXT NOT NULL DEFAULT 'low',
        requires_review INTEGER NOT NULL DEFAULT 0,
        boundary_notice TEXT,
        rules_version TEXT,
        model_version TEXT,
        model_type TEXT,
        cluster_id INTEGER,
        pc1 REAL,
        pc2 REAL,
        nearest_distance REAL,
        second_distance REAL,
        report_json TEXT NOT NULL DEFAULT '{}',
        visuals_json TEXT NOT NULL DEFAULT '{}',
        legacy_source_id TEXT,
        legacy_source_table TEXT,
        export_allowed INTEGER NOT NULL DEFAULT 1,
        data_quality TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS student_profile_followups (
        id TEXT PRIMARY KEY,
        profile_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        round_no INTEGER NOT NULL,
        fit TEXT,
        task_done TEXT,
        state_score INTEGER,
        text TEXT,
        keywords_json TEXT NOT NULL DEFAULT '[]',
        created_at TEXT NOT NULL,
        export_allowed INTEGER NOT NULL DEFAULT 1
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS student_sandplay_entries (
        id TEXT PRIMARY KEY,
        profile_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        task_title TEXT,
        scene_json TEXT NOT NULL,
        reflection_text TEXT,
        summary_json TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL,
        export_allowed INTEGER NOT NULL DEFAULT 1
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS parent_assessment_submissions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        anonymous_id TEXT NOT NULL,
        participant_code TEXT,
        research_consent INTEGER NOT NULL DEFAULT 0,
        study_batch TEXT,
        source_channel TEXT,
        questionnaire_version TEXT,
        scoring_version TEXT,
        answers_json TEXT NOT NULL,
        scores_json TEXT NOT NULL,
        profile_key TEXT,
        report_json TEXT NOT NULL,
        started_at TEXT,
        completed_at TEXT,
        duration_seconds INTEGER NOT NULL DEFAULT 0,
        quality_flags_json TEXT NOT NULL DEFAULT '{}',
        legacy_source_id TEXT,
        legacy_source_table TEXT,
        export_allowed INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS parent_report_actions (
        id TEXT PRIMARY KEY,
        submission_id TEXT NOT NULL,
        action_key TEXT NOT NULL,
        created_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS profile_reviews (
        id TEXT PRIMARY KEY,
        profile_id TEXT NOT NULL,
        reviewer_id TEXT,
        review_status TEXT NOT NULL DEFAULT 'reviewed',
        review_decision TEXT,
        note TEXT,
        action_summary TEXT,
        visible_to_student INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS records (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        module_type TEXT NOT NULL,
        source_id TEXT,
        data_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        export_allowed INTEGER NOT NULL DEFAULT 1
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        actor_id TEXT,
        action TEXT NOT NULL,
        target_type TEXT,
        target_id TEXT,
        metadata_json TEXT NOT NULL,
        created_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS consent_records (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        consent_type TEXT NOT NULL,
        consent_version TEXT NOT NULL,
        agreed INTEGER NOT NULL,
        agreed_at TEXT NOT NULL,
        revoked_at TEXT,
        created_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS risk_review_records (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        source_type TEXT NOT NULL,
        source_id TEXT NOT NULL,
        risk_level TEXT NOT NULL,
        matched_categories_json TEXT NOT NULL DEFAULT '[]',
        review_status TEXT NOT NULL DEFAULT 'pending',
        reviewer_id TEXT,
        review_note TEXT,
        action_taken TEXT,
        closed_reason TEXT,
        reviewed_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS weekly_reports (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        week_start TEXT NOT NULL,
        week_end TEXT NOT NULL,
        frequent_scenes_json TEXT NOT NULL,
        frequent_emotions_json TEXT NOT NULL,
        common_patterns_json TEXT NOT NULL,
        completed_cards_json TEXT NOT NULL,
        next_week_suggestion TEXT,
        created_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS supervision_requests (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        diary_id TEXT,
        message TEXT NOT NULL,
        contact TEXT,
        risk_hint TEXT,
        risk_level TEXT NOT NULL DEFAULT 'low',
        status TEXT NOT NULL DEFAULT 'pending',
        supervisor_reply TEXT,
        created_at TEXT NOT NULL,
        replied_at TEXT
    )
    """,
]


INDEX_SQL = [
    "CREATE INDEX IF NOT EXISTS idx_emotion_diaries_user_created ON emotion_diaries(user_id, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)",
    "CREATE INDEX IF NOT EXISTS idx_feedback_results_user_created ON feedback_results(user_id, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_student_profiles_user_created ON student_profiles(user_id, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_student_profiles_risk_created ON student_profiles(risk_level, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_risk_review_status_created ON risk_review_records(review_status, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_audit_logs_action_created ON audit_logs(action, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_records_module_created ON records(module_type, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_privacy_requests_user_created ON privacy_requests(user_id, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_family_links_code_status ON family_links(bind_code, status)",
]
